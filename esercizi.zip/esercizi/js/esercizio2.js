//esercizio 2

let  annoNascita=prompt(('Ciao inserisci il tuo anno di Nascita: '));
let annoCorrente=prompt('Inserisci l\'anno corrente');

console.log('Sei nato nel: '+ annoNascita);
console.log('Siamo nel:  '+ annoCorrente);