//esercizio 3

let num1=prompt('inserisci primo numero: ');
let num2=prompt('inserisci secondo numero: ');
console.log(num1*num2);
