let num1=8;
let num2=4;
let moltiplicazione=num1*num2;
console.log(moltiplicazione);
let divisione=num1/num2;
console.log(divisione);


moltiplicazione=document.getElementById('moltiplicazione');
divisione=document.getElementById('divisione');
divisione.innerHTML+='<p>'+divisione+'</p>';
moltiplicazione.innerHTML+='<p>'+moltiplicazione+'</p>'

