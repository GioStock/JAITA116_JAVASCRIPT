let file= 'File.html';
let estensione= file.split('.').pop();
console.log('l\'estensione del file è: '+estensione);