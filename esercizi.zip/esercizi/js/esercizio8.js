//Esercizio 8 – Scrivere un programma che inverte una parola fornita in un campo di testo nel HTML e un  bottone che chiama la funzione  

let ciao = prompt('Inserisci una frase ed io te la converto: ').split('').reverse('').join('');

console.log ('questa è la frase convertita: '+ciao);