// Esercizio 14 – Scrivi un programma per trasformare un array di elementi (stringhe) in un’unica stringa,  utilizza tutti i metodi che conosci 
let stringa=['ciao','come','va'];
let stringa1= stringa.join(' ')
console.log(stringa1);